<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class themaController extends Controller
{
    public function thema()
    {
        return view('thema');
    }
}
