<?php

namespace App\Http\Controllers;

use App\Models\noticia;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class NoticiaController extends Controller
{
   public function noticias(){

      $note=noticia::all();
      $not=DB::table('noticias')
        ->orderBy('id','desc')
        ->paginate(9);

    return view('/noticias',['note'=>$note,'not'=>$not]);
   }

}
