<link href="/assets/styless/styless.css" rel="stylesheet">
<!--Nombre de Pestaña-->
<?php $__env->startSection('title', 'Dashboard'); ?> 
<!--barra lateral -->


<?php $__env->startSection('content'); ?>
<div class="container ">
  <?php if(session('mensaje')): ?>
      <div class="alert alert-success">
          <?php echo e(session('mensaje')); ?>

      </div>
  <?php endif; ?>

<!--Inicio modal crear Proyectos -->
<!-- Button trigger modal -->
<br>
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal">
Subir Nueva Foto
</button>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
        <div class="container text-center bg-primary box-header "><h4>Nueva Foto</h4></div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <div class="row p-3">
            <div class=" col-12 ">
                <form action="<?php echo e(route ('foto.crear')); ?>" method="POST"enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                    <div class="form-group">
                      <label for="foto">Foto</label>
                      <input type="file" name = "foto" class="form-control" id="exampleFormControlInput3"  accept=image/* required>
                    </div>
                    <div class="form-group ">
                      <label for="exampleFormControlSelect1">Seccion</label>
                      <select class="form-control"  name ="seccion" id="exampleFormControlSelect1">
                        <option>--Selecciones Area de Trabajo--</option>
                        <option>Home-footer</option>
                        <option>Cientifico Humanista</option>
                        <option>Construcion Metálicas</option>
                        <option>Electricidad</option>
                        <option>Quimica Industrial</option>
                    </select>
                    </div>
                    </div>
                    <button class="btn btn-primary" type="submit">Guardar</button>
                  </form>
            </div>
            </div>
    </div>
      </div>
      
    </div>
  </div>
</div>
<br>
<div class="container">

  <div class="row">
    <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
    <div class="card ml-3" style="width: 15rem;">
      <img src="<?php echo e(asset($fotos->foto)); ?>" class="card-img-top" alt="...">
      <div class="card-body text-center">
        <a href="<?php echo e(route ('foto.edit',$fotos->id)); ?>" class="btn btn-warning ">editar</a>
        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modal-delete-<?php echo e($fotos->id); ?>">
          Eliminar
        </button>
        <br>
        <p><?php echo e($fotos->seccion); ?></p>
      </div>
    </div>
    <?php echo $__env->make('/admin/foto/delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <br>
  </div>
  
</div>

<?php echo e($foto->links()); ?>






<!---->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<script>CKEDITOR.replace( 'editor1' );</script>
 <!---->   
<?php $__env->stopSection(); ?>

    


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\LARAVEL\liceo_chagres\resources\views//admin/foto/foto.blade.php ENDPATH**/ ?>