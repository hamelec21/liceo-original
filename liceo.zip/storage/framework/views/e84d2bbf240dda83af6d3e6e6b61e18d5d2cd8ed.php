
<link href="/assets/styless/styless.css" rel="stylesheet">
<!--Nombre de Pestaña-->
<?php $__env->startSection('title', 'Dashboard'); ?> 
<!--barra lateral -->


<?php $__env->startSection('content'); ?>

<div class="container">

<div class="row p-3">
    <div class=" col-12 ">
      <form action="<?php echo e(route ('nosotro.update',$note->id)); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="exampleFormControlInput1">Seccion</label>
              <input type="text" name = "seccion" class="form-control" id="parnets" value ="<?php echo e($note->seccion); ?>"readonly >
            </div>
            <div class="form-group">
              <label for="exampleFormControlInput11">Descripción</label>
              <textarea id ="editor2"  name ="contenido"   value ="<?php echo e($note->contenido); ?>" ><?php echo $note->contenido; ?></textarea>
            </div>
            <div class="form-group">
              <label for="foto">Foto</label>
              <input type="file" name = "foto" class="form-control" id="foto" value ="<?php echo e($note->foto); ?>"  >
            </div>
            
            <button class="btn btn-warning " type="submit">Guardar</button>
            
      </form>
    </div>
    </div>

</div>

    <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<script>

CKEDITOR.replace( 'editor2' );
</script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fernand8/public_html/liceo/resources/views//admin/nosotro/editar.blade.php ENDPATH**/ ?>