<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Formulario de Contacto</h1>
    
    <p><strong>Nombre:</strong><?php echo e($contacto['nombre']); ?></p>
    <p><strong>Correo:</strong><?php echo e($contacto['correo']); ?></p>
    <p><strong>Mensaje:</strong><?php echo e($contacto['mensaje']); ?></p>
</body>
</html><?php /**PATH C:\wamp64\www\LARAVEL\liceo_chagres\resources\views//emails/contactanos.blade.php ENDPATH**/ ?>