<footer class="ftco-footer ftco-bg-dark ftco-section">
    <div class="container">
      
      <div class="row">
        <div class="col-md-12 text-center">

          <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> Todos Los Derechos Reservados | Diseño <i class="icon-rabbit" aria-hidden="true"></i>Web por<a href="https://www.rabbitagenciadigital.cl" target="_blank"> Rabbit Agencia Digital </a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
        </div>
      </div>
    </div>
  </footer>
  <?php /**PATH C:\wamp64\www\LARAVEL\liceo_chagres\resources\views/footer.blade.php ENDPATH**/ ?>